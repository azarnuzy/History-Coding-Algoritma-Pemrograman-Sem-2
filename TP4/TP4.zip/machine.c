#include "header.h"

/*Saya Muhammad Azar Nuzy 2004191 mengerjakan soal Kompetisi TP4 Alpro2 2021 C1 dalam 
mata kuliah Algoritma dan Pemrograman untuk keberkahanNya maka saya tidak melakukan kecurangan
seperti yang telah dispesifikasikan. Aamiin*/

void ubahNilai(int n, laporan masukan){					//membuat prosedur untuk mengubah nilai dari tipedata terstruktur menjadi integer
	int i;	//membuat iterator

	for(i=0; i<n; i++){									//membuat perulangan untuk mengubah nilai
		tempNama[i] = masukan.nama[i][0];				//menyimpan nama
		tempHarga[i] = masukan.harga[i];				//menyimpan harga
		tempNilai[i] = masukan.nilai[i] * 1000 + .5;	//menyimpan nilai *+.5 agar nilai dari float menjadi presisi
	}
}

void insertion(int n,int x[]){							//membuat prosedur untuk mengurutkan laporan dengan cara insertion
	int i,j;		//sebagai iterator
	int temp;		//seabagi tempat penampungan dari nilai yang akan di urutkan

	int tempX[n];	//membuat arr of integer untuk membuat tempat penampungan sementara dari nilai utama yang akan diurutkan 
	int cek = 1;	//sebagai pengkondisian untuk keluar dari perulangan 

	for(i=0; i<n; i++){		//membuat perulangan untuk menampung nilai utama yang akan diurutkan
		tempX[i] = x[i];	//menyimpan nilai utama di tempat penampungan
	}

	for(i=1; i<n; i++){		//membuat perulangan untuk mengurutkan nilai 
		temp = x[i];		//membuat penampungan sementara untuk nilai yang akan di bandingkan
		j=i-1;				
		if(strcmp(urut, "asc") == 0){		//membuat pengkondisian untuk cara mengurutkan dari kecil ke besar
			while(temp < x[j] && j >= 0){	//membuat perulangan dengan syarat jika nilai penampung lebih kecil dari nilai yang dibandingkan maka akan masuk dalam perulangan tersebut
				x[j+1] = x[j];				//nilai di depan akan menyimpan nilai sebelmnya 
				j--;						
			}
			x[j+1] = temp;					//menyimpan nilai dari tampungan sementara
		}else{								//membuat pengkondisian untuk cara mengurutkan dari besar ke kecil
			while(temp > x[j] && j >= 0){	//membuat perulangan dengan syarat jika nilai penampung lebih besar dari nilai yang dibandingkan maka akan masuk dalam perulangan tersebut
				x[j+1] = x[j];				//nilai di depan akan menyimpan nilai sebelmnya 
				j--;
			}
			x[j+1] = temp;					//menyimpan nilai dari tampungan sementara
		}
	}

	for(i=0; i<n; i++){				//membuat perulangan untuk mencari index2 dari yang diurutkan 
		j=n-1;
		cek = 1;					//sebagai pengkondisian dari pengulangan		
		while(cek == 1 && j>=0){		//membuat perulangan jika cek berubah nilai maka akan keluar dari perulangan tersebut
			if(x[i] == tempX[j]){	//membuat pengkondisian jika nilai yang telah diurtkan bertemu dengan nilai tampungan utama 
				index2[i] = j;		//menyimpan nilai index2 dari hasil yang sama
				tempX[j] = -1;		//membuat nilai penampungan utama menjadi -1 agar tidak dijadikan sebagai kondisi berulang
				cek = 0;			//mengubah nilai cek menjadi nol
			}
			j--;
		}
	}
}

void selection(int n, int x[]){
	int i,j;
	int index1;
	int temp;				//seabagi tempat penampungan dari nilai yang akan di urutkan
	
	int tempX[n];			//membuat arr of integer untuk membuat tempat penampungan sementara dari nilai utama yang akan diurutkan 
	int cek = 1;			//sebagai pengkondisian untuk keluar dari perulangan 

	for(i=0; i<n; i++){		//membuat perulangan untuk menampung nilai utama yang akan diurutkan
		tempX[i] = x[i];	//menyimpan nilai utama di tempat penampungan
	}

	for(i=0; i<n-1; i++){	//membuat perulangan untuk mengurutkan nilai dengan cara selection
		index1 = i;

		for(j=i+1; j<n; j++){	
			if(x[index1] < x[j] && strcmp(urut, "asc")){ 			//sebagai pengkondisian untuk mencari nilai yang lebih kecil
				index1 = j;											//untuk menyimpan nilai dari index2 nilai yang lebih kecil
			}else if(x[index1] > x[j] && strcmp(urut, "desc")){	//sebagai pengkondisian untuk mencari nilai yang lebih besar
				index1 = j;											//untuk menyimpan nilai dari index2 nilai yang lebih kecil
			}
		}
		
		temp = x[i];		//untuk menyimpan sementara dari nilai x[i]
		x[i] = x[index1];	//menyimpan nilai sesuai dengan yang telah diubah dari perulangan di atas
		x[index1] = temp;	//menukar nilai dari nilai yang ditukar di atas
	}

	for(i=0; i<n; i++){				//membuat perulangan untuk mencari index2 dari yang diurutkan 
		j=n-1;						//membuat iterator dengan nilai dari nilai jumlah data
		cek = 1;					//sebagai pengkondisian dari pengulangan		
		while(cek == 1 && j>=0){	//membuat perulangan jika cek berubah nilai maka akan keluar dari perulangan tersebut
			if(x[i] == tempX[j]){	//membuat pengkondisian jika nilai yang telah diurtkan bertemu dengan nilai tampungan utama 
				index2[i] = j;		//menyimpan nilai index2 dari hasil yang sama
				tempX[j] = -1;		//membuat nilai penampungan utama menjadi -1 agar tidak dijadikan sebagai kondisi berulang
				cek = 0;			//mengubah nilai cek menjadi nol
			}
			j--;					
		}
	}
}

void tampil(int n, laporan masukan){			//membuat prosedur untuk nilai tampilan dari nilai yang telah diurutkan
	int i;
	for(i=0; i<n; i++){														//sebagai perulangan untuk keluaran
		int harga1 = masukan.harga[index2[i]];								//membuat tempat penyimpanan sementara agar pada code tidak ditulis terlalu panjang
		float nilai1 = masukan.nilai[index2[i]];							//membuat tempat penyimpanan sementara agar pada code tidak ditulis terlalu panjang
		printf("%s %d %0.1f\n", masukan.nama[index2[i]], harga1, nilai1);	//membuat keluaran sesuai dengan yang telah diurutkan
	}
}